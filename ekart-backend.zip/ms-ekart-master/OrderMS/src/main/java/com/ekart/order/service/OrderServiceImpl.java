package com.ekart.order.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ekart.order.dto.OrderDTO;
import com.ekart.order.entity.Order;
import com.ekart.order.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private OrderRepository orderRepo;

	@Override
	public OrderDTO createOrder(OrderDTO orderDTO) {
		// TODO Auto-generated method stub
		Order order = Order.prepareOrderEntity(orderDTO);
		order.setStatus("ordered");
		order.setEstimatedDeliverDate(order.getOrderDate().plusDays(5));
		orderRepo.save(order);
		return OrderDTO.prepareOrderDTO(order);
	}

	@Override
	public List<OrderDTO> getAllBuyerOrders(Integer buyerId) {
		// TODO Auto-generated method stub
		List<Order> allOrders = orderRepo.findByBuyerId(buyerId);
		List<OrderDTO> allOrderDTOs = new ArrayList<>();
		for(Order order: allOrders) {
			allOrderDTOs.add(OrderDTO.prepareOrderDTO(order));
		}
		allOrderDTOs.sort((order1, order2) -> order2.getOrderDate().compareTo(order1.getOrderDate()));
		return allOrderDTOs;
	}
	
	@Override
	public List<OrderDTO> getAllSellerOrders(Integer sellerId) {
		List<Order> allOrders = orderRepo.findBySellerId(sellerId);
		List<OrderDTO> allOrderDTOs = new ArrayList<>();
		for(Order order: allOrders) {
			allOrderDTOs.add(OrderDTO.prepareOrderDTO(order));
		}
		allOrderDTOs.sort((order1, order2) -> order2.getOrderDate().compareTo(order1.getOrderDate()));
		return allOrderDTOs;
		
	}
	
	@Override
	public List<OrderDTO> filterOrders(Integer buyerId, String status) {
		if(status.length() == 0) 
			return getAllBuyerOrders(buyerId);
		List<Order> orders = orderRepo.findByBuyerIdAndStatus(buyerId, status);
		List<OrderDTO> orderDTOs = new ArrayList<>();
		for(Order order: orders) {
			orderDTOs.add(OrderDTO.prepareOrderDTO(order));
		}
		return orderDTOs;
	}
	
	@Override
	public Boolean deliveredOrder(Integer orderId) {
		Order order = orderRepo.findByOrderId(orderId);
		if(order == null)
			return false;
		
		if(order.getStatus().equals("ordered")) {
			order.setStatus("delivered");
			order.setDeliverDate(LocalDate.now());
			orderRepo.save(order);
			return true;
			
			/* This MS only needs to update the delivery status.
			 * Notification MS will fetch all the status by calling "/order/buyer/{buyerId}" of this MS.
			 * So it doesn't need to call notification MS explicitly. */
			
			//String sellerNotificationUrl = "http://localhost:8000/ekart/seller/notify";
			//String sellerNotification = "Delivered the product" + order.getProductId() + " to customer " + order.getBuyerId();
			//API call to push notification to seller notifications
			//new RestTemplate().postForObject(sellerNotificationUrl, sellerNotification, Object.class);
		}
		return false;
	}
	
	@Override
	public Boolean cancelOrder(Integer orderId) {
		Order order = orderRepo.findByOrderId(orderId);
		if(order == null)
			return false;
		if(order.getStatus().equals("ordered")) {
			order.setStatus("cancelled");
			orderRepo.save(order);
			return true;
		}
		return false;
	}
	
	@Override
	public Boolean returnOrder(Integer orderId) {
		Order order = orderRepo.findByOrderId(orderId);
		if(order == null)
			return false;
		if(order.getStatus().equals("delivered")) {
			LocalDateTime present = LocalDateTime.now();
			if(ChronoUnit.DAYS.between(order.getDeliverDate(), present) > 10)
				return false;
			order.setStatus("returned");
			orderRepo.save(order);
			return true;
		}
		return false;
	}

	
}
