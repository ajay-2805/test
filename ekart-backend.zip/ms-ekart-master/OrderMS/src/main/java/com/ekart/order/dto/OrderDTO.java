package com.ekart.order.dto;

import java.time.LocalDate;

import javax.validation.constraints.NotEmpty;

import com.ekart.order.entity.Order;

public class OrderDTO {

	int orderId;
	
	int buyerId;
	
	LocalDate orderDate;
	
	LocalDate estimatedDeliverDate;
	
	LocalDate deliverDate;
	
	int productId;
	
	int sellerId;
	
	int quantity;
	
	String address;
	
	long cardNo;
	
	String status;
	
	public OrderDTO() {
		super();
	}

	public OrderDTO(int orderId, @NotEmpty(message = "Buyer Id is must") int buyerId, LocalDate orderDate,
			LocalDate estimatedDeliverDate, LocalDate deliverDate, @NotEmpty(message = "There should be at least 1 product to order") int productId,
			int sellerId, @NotEmpty(message = "Quantity must be mentioned") int quantity, String address,
			long cardNo, String status) {
		super();
		this.orderId = orderId;
		this.buyerId = buyerId;
		this.orderDate = orderDate;
		this.estimatedDeliverDate = estimatedDeliverDate;
		this.deliverDate = deliverDate;
		this.productId = productId;
		this.sellerId = sellerId;
		this.quantity = quantity;
		this.address = address;
		this.cardNo = cardNo;
		this.status = status;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public LocalDate getEstimatedDeliverDate() {
		return estimatedDeliverDate;
	}

	public void setEstimatedDeliverDate(LocalDate estimatedDeliverDate) {
		this.estimatedDeliverDate = estimatedDeliverDate;
	}

	public LocalDate getDeliverDate() {
		return deliverDate;
	}

	public void setDeliverDate(LocalDate deliverDate) {
		this.deliverDate = deliverDate;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}
	
	public int getSellerId() {
		return sellerId;
	}
	
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public long getCardNo() {
		return cardNo;
	}
	
	public void setCardNo(long cardNo) {
		this.cardNo = cardNo;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	public static OrderDTO prepareOrderDTO(Order order) {
		return new OrderDTO(order.getOrderId(), order.getBuyerId(), order.getOrderDate(), order.getEstimatedDeliverDate(),
				order.getDeliverDate(), order.getProductId(), order.getSellerId(), order.getQuantity(), 
				order.getAddress(), order.getCardNo(), order.getStatus());
	}
}
