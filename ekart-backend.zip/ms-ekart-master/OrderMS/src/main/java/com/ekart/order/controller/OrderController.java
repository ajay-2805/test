package com.ekart.order.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ekart.order.dto.OrderDTO;
import com.ekart.order.service.OrderService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@RequestMapping("/order")
public class OrderController {

	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private OrderService orderService;
	
	@PostMapping("")
	@HystrixCommand(fallbackMethod  = "fallbackForCreateOrder")
	public ResponseEntity<OrderDTO> createOrder(@RequestBody OrderDTO orderDTO) {
		OrderDTO orderCreated = orderService.createOrder(orderDTO);
		return new ResponseEntity<>(orderCreated, HttpStatus.CREATED);
	}
	
	/*
	 * Fallback method for order creation
	 */
	
	public ResponseEntity<OrderDTO> fallbackForCreateOrder(OrderDTO orderDTO) {
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@GetMapping("/buyer/{buyerId}")
	@HystrixCommand(fallbackMethod = "fallbackForBuyerOrders")
	public ResponseEntity<List<OrderDTO>> getAllBuyersOrders(@PathVariable int buyerId) {
		List<OrderDTO> allBuyersOrders = orderService.getAllBuyerOrders(buyerId);
		return new ResponseEntity<>(allBuyersOrders, HttpStatus.OK);
	}
	
	/*
	 * Fallback method for buyer orders
	 */
	
	public ResponseEntity<List<OrderDTO>> fallbackForBuyerOrders(@PathVariable int buyerId) {
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@GetMapping("/seller/{sellerId}")
	@HystrixCommand(fallbackMethod = "fallbackForSellerOrders")
	public ResponseEntity<List<OrderDTO>> getAllSellerOrders(@PathVariable int sellerId) {
		List<OrderDTO>  allSellerOrders = orderService.getAllSellerOrders(sellerId);
		return new ResponseEntity<>(allSellerOrders, HttpStatus.OK);
	}
	
	/*
	 * Fallback for seller orders
	 */
	
	public ResponseEntity<List<OrderDTO>> fallbackForSellerOrders(@PathVariable int sellerId) {
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@PutMapping("/deliver/{orderId}")
	@HystrixCommand(fallbackMethod = "fallbackForDeliverOrder")
	public ResponseEntity<Boolean> deliveredOrder(@PathVariable int orderId) {
		return new ResponseEntity<>(orderService.deliveredOrder(orderId), HttpStatus.OK);
	}
	
	/*
	 * Fallback for delivering order
	 */
	
	public ResponseEntity<Boolean> fallbackForDeliverOrder(@PathVariable int orderId) {
		return new ResponseEntity<>(false, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@PutMapping("/cancel/{orderId}")
	@HystrixCommand(fallbackMethod = "fallbackForCancelOrder")
	public ResponseEntity<Boolean> cancelOrder(@PathVariable int orderId) {
		return new ResponseEntity<>(orderService.cancelOrder(orderId), HttpStatus.OK);
	}
	
	/*
	 * Fallback for cancelling order
	 */
	
	public ResponseEntity<Boolean> fallbackForCancelOrder(@PathVariable int orderId) {
		return new ResponseEntity<>(false, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@PutMapping("/return/{orderId}")
	@HystrixCommand(fallbackMethod = "fallbackForReturnOrder")
	public ResponseEntity<Boolean> returnOrder(@PathVariable int orderId) {
		return new ResponseEntity<>(orderService.returnOrder(orderId), HttpStatus.OK);
	}
	
	/*
	 * Fallback for returning order
	 */
	
	public ResponseEntity<Boolean> fallbackForReturnOrder(@PathVariable int orderId) {
		return new ResponseEntity<>(false, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
