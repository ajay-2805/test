package com.ekart.order.service;

import java.util.List;

import com.ekart.order.dto.OrderDTO;

public interface OrderService {

	public OrderDTO createOrder(OrderDTO orderDTO);
	
	public List<OrderDTO> getAllBuyerOrders(Integer buyerId);
	
	public List<OrderDTO> getAllSellerOrders(Integer sellerId);
	
	public List<OrderDTO> filterOrders(Integer buyerId, String status);
	
	public Boolean deliveredOrder(Integer orderId);
	
	public Boolean cancelOrder(Integer orderId);
	
	public Boolean returnOrder(Integer orderId);
}
