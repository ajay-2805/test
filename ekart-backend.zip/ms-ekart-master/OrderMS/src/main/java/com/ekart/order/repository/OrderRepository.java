package com.ekart.order.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ekart.order.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Integer> {

	/*@Query(value = "select o from o.order where o.buyer_id=?1", nativeQuery = true)
	public List<Order> getOrdersByBuyerId(Integer buyerId);*/
	
	Order findByOrderId(Integer orderId);
	
	@Query(value = "select * from ekartorder where buyer_id=?", nativeQuery = true)
	List<Order> findByBuyerId(Integer buyerId);
	
	@Query(value = "select * from ekartorder where buyer_id=? and status=?", nativeQuery = true)
	List<Order> findByBuyerIdAndStatus(Integer buyerId, String status);
	
	@Query(value = "select * from ekartorder where seller_id=?", nativeQuery = true)
	List<Order> findBySellerId(Integer sellerId);
	
}
