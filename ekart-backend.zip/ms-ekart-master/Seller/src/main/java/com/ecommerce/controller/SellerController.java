package com.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.dto.ProductsDTO;
import com.ecommerce.dto.SellerDetailsDTO;
import com.ecommerce.exception.SellerException;
import com.ecommerce.service.SellerService;

@RestController
@CrossOrigin
@RequestMapping("/products")
public class SellerController {

	@Autowired
	SellerService sellerService;
	
	@PostMapping
	public ResponseEntity<Integer> addNewProduct(@RequestBody ProductsDTO product) throws SellerException {
		
		return ResponseEntity.ok(sellerService.addProduct(product));
	}
	
	@GetMapping("/{sellerId}")
	public ResponseEntity<List<ProductsDTO>> getSellersProducts(@PathVariable("sellerId") String sellerId) throws SellerException {
		
		return ResponseEntity.ok(sellerService.getSellersProduct(sellerId)); 
	}
	
	@PutMapping
	public ResponseEntity<Boolean> updateProductDetails(@RequestBody ProductsDTO product) {
		
		return ResponseEntity.ok(sellerService.updateProductDetails(product));
	}
	
	@GetMapping
	public ResponseEntity<List<ProductsDTO>> getAllProducts() {
		
		return ResponseEntity.ok(sellerService.getAllProducts());
	}
	
	@GetMapping("/search/{searchBy}")
	public ResponseEntity<List<ProductsDTO>> searchProducts(@PathVariable String searchBy) {
		
		return ResponseEntity.ok(sellerService.searchByUserInput(searchBy.toLowerCase()));
	}
	
	@GetMapping("/category/{categoryName}")
	public ResponseEntity<List<ProductsDTO>> getProductsByCategory(@PathVariable String categoryName) {
		
		return ResponseEntity.ok(sellerService.getProductsByCategory(categoryName.toLowerCase()));
	}
	
	@GetMapping("/product/{productId}")
	public ResponseEntity<ProductsDTO> getByProductId(@PathVariable Integer productId) {
		
		return ResponseEntity.ok(sellerService.getProductByProductId(productId));
	}
	
	@GetMapping("/seller/{productId}")
	public ResponseEntity<List<SellerDetailsDTO>> getAllSellersOfProduct(@PathVariable Integer productId) {
		
		return ResponseEntity.ok(sellerService.getAllSellersOfProduct(productId));
	}
	
	@GetMapping("/category/random/{categoryName}")
	public ResponseEntity<ProductsDTO> getRandomProducyByCategoryName(@PathVariable String categoryName) {
		
		return ResponseEntity.ok(sellerService.getRandomProductByCategory(categoryName));
	}
}