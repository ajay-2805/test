package com.ecommerce.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.ecommerce.dto.ProductsDTO;

@Entity
@Table(name = "tbProducts")
@GenericGenerator(name = "idGen", strategy = "increment")
public class ProductsEntity {

	@Id
	@GeneratedValue(generator = "idGen")
	private Integer productId;
	private String sellerId;
	private String productName;
	private String categoryName;
	private Float price;
	private Integer discount;
	private String shortDescription;
	private String description;
	private Float effectivePrice;
	private Integer quantitiesSold;
	private Double totalEarned;

	public Integer getQuantitiesSold() {
		return quantitiesSold;
	}

	public void setQuantitiesSold(Integer quantitiesSold) {
		this.quantitiesSold = quantitiesSold;
	}

	public Double getTotalEarned() {
		return totalEarned;
	}

	public void setTotalEarned(Float effectivePrice, Integer quantitiesSold) {
		this.totalEarned = (double) (effectivePrice * quantitiesSold);
	}

	public Float getEffectivePrice() {
		return effectivePrice;
	}

	public void setEffectivePrice(Integer discount, Float price) {
		this.effectivePrice = price - (price * discount) / 100;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId.trim().replaceAll(" +", " ");
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName.trim().replaceAll(" +", " ");
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName.trim().replaceAll(" +", " ");
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Integer getDiscount() {
		return discount;
	}

	public void setDiscount(Integer discount) {
		this.discount = discount;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription.trim().replaceAll(" +", " ");
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description.trim().replaceAll(" +", " ");
	}

	public Integer getProductId() {
		return productId;
	}

	public static ProductsDTO prepareProductsDTO(ProductsEntity prod) {

		ProductsDTO dto = new ProductsDTO();

		dto.setProductId(prod.getProductId());
		dto.setCategoryName(prod.getCategoryName());
		dto.setDescription(prod.getDescription());
		dto.setDiscount(prod.getDiscount());
		dto.setPrice(prod.getPrice());
		dto.setProductName(prod.getProductName());
		dto.setSellerId(prod.getSellerId());
		dto.setShortDescription(prod.getShortDescription());
		dto.setEffectivePrice(prod.getEffectivePrice());
		dto.setQuantitiesSold(prod.getQuantitiesSold());
		dto.setTotalEarned(prod.getTotalEarned());

		return dto;
	}
}
