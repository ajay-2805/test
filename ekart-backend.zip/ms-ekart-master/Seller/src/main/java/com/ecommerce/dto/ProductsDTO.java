package com.ecommerce.dto;

import com.ecommerce.entity.ProductsEntity;

public class ProductsDTO {

	private Integer productId;
	private String sellerId;
	private String productName;
	private String categoryName;
	private Float price;
	private Integer discount;
	private String shortDescription;
	private String description;
	private Float effectivePrice;
	private Integer quantitiesSold;
	private Double totalEarned;

	@Override
	public String toString() {
		return "ProductsDTO [productId=" + productId + ", sellerId=" + sellerId + ", productName=" + productName
				+ ", categoryName=" + categoryName + ", price=" + price + ", discount=" + discount
				+ ", shortDescription=" + shortDescription + ", description=" + description + "]";
	}

	public Integer getQuantitiesSold() {
		return quantitiesSold;
	}

	public void setQuantitiesSold(Integer quantitiesSold) {
		this.quantitiesSold = quantitiesSold;
	}

	public Double getTotalEarned() {
		return totalEarned;
	}

	public void setTotalEarned(Double totalEarned) {
		this.totalEarned = totalEarned;
	}

	public Float getEffectivePrice() {
		return effectivePrice;
	}

	public void setEffectivePrice(Float effectivePrice) {
		this.effectivePrice = effectivePrice;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId.trim().replaceAll(" +", " ");
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName.trim().replaceAll(" +", " ");
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName.trim().replaceAll(" +", " ");
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Integer getDiscount() {
		return discount;
	}

	public void setDiscount(Integer discount) {
		this.discount = discount;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription.trim().replaceAll(" +", " ");
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description.trim().replaceAll(" +", " ");
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public static ProductsEntity prepareProductsEntity(ProductsDTO prod) {

		ProductsEntity entity = new ProductsEntity();

		entity.setCategoryName(prod.getCategoryName());
		entity.setDescription(prod.getDescription());
		entity.setDiscount(prod.getDiscount());
		entity.setPrice(prod.getPrice());
		entity.setProductName(prod.getProductName());
		entity.setSellerId(prod.getSellerId());
		entity.setShortDescription(prod.getShortDescription());
		entity.setEffectivePrice(prod.getDiscount(), prod.getPrice());
		entity.setQuantitiesSold(prod.getQuantitiesSold() != null ? prod.getQuantitiesSold() : 0);
		entity.setTotalEarned(entity.getEffectivePrice(), entity.getQuantitiesSold());

		return entity;
	}

	public static ProductsEntity prepareProductsEntity(ProductsDTO prod, ProductsEntity ent) {

		ent.setCategoryName(prod.getCategoryName() != null ? prod.getCategoryName() : ent.getCategoryName());
		ent.setDescription(prod.getDescription() != null ? prod.getDescription() : ent.getDescription());
		ent.setDiscount(prod.getDiscount() != null ? prod.getDiscount() : ent.getDiscount());
		ent.setPrice(prod.getPrice() != null ? prod.getPrice() : ent.getPrice());
		ent.setProductName(prod.getProductName() != null ? prod.getProductName() : ent.getProductName());
		ent.setSellerId(prod.getSellerId() != null ? prod.getSellerId() : ent.getSellerId());
		ent.setShortDescription(
				prod.getShortDescription() != null ? prod.getShortDescription() : ent.getShortDescription());
		ent.setEffectivePrice(ent.getDiscount(), ent.getPrice());
		ent.setQuantitiesSold(prod.getQuantitiesSold() != null ? prod.getQuantitiesSold() : ent.getQuantitiesSold());
		ent.setTotalEarned(ent.getEffectivePrice(), ent.getQuantitiesSold());

		return ent;
	}
}