package com.ecommerce.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ecommerce.entity.ProductsEntity;

public interface SellerRepository extends JpaRepository<ProductsEntity, Integer> {
	
	final String PRODUCT_MIN_PRICE_SELLER = "SELECT * FROM tb_Products P INNER JOIN (SELECT product_name, MIN(effective_price) "
			+ "effective_price FROM tb_products group by product_name) AS A ON P.product_name = A.product_name "
			+ "WHERE P.effective_price = A.effective_price";
	
	List<ProductsEntity> findBySellerId(String sellerId);
	
	@Query(value = PRODUCT_MIN_PRICE_SELLER, nativeQuery = true)
	List<ProductsEntity> getAllProducts();
	
	ProductsEntity findByProductNameAndSellerId(String prodName, String sellerId);
	
	@Query(value = PRODUCT_MIN_PRICE_SELLER + " AND P.product_name LIKE ?1%", nativeQuery = true)
	List<ProductsEntity> searchByUserFilter(String searchBy);
	
	@Query(value = PRODUCT_MIN_PRICE_SELLER + " AND P.category_name = ?1", nativeQuery = true)
	List<ProductsEntity> findByCategoryName(String categoryName);
	
	List<ProductsEntity> findByProductName(String productName);
	
	@Query(value = "SELECT * FROM ecomseller.tb_Products WHERE category_name = ?1 ORDER BY RAND() LIMIT 1", nativeQuery = true)
	ProductsEntity findOneByCategoryName(String categoryName);
}