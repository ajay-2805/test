package com.ecommerce.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.client.AccountClient;
import com.ecommerce.dto.AccountDTO;
import com.ecommerce.dto.ProductsDTO;
import com.ecommerce.dto.SellerDetailsDTO;
import com.ecommerce.entity.ProductsEntity;
import com.ecommerce.exception.ExceptionConstants;
import com.ecommerce.exception.SellerException;
import com.ecommerce.repository.SellerRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service("sellerService")
public class SellerServiceImpl implements SellerService {

	@Autowired
	SellerRepository sellerRepo;
	
	@Autowired
	AccountClient accountClient;
	
	@Override
	public Integer addProduct(ProductsDTO productsDTO) throws SellerException {
		
		ProductsEntity productsEntity;
		
		productsEntity = sellerRepo.findByProductNameAndSellerId(productsDTO.getProductName(), productsDTO.getSellerId());
		
		if(productsEntity != null)
			throw new SellerException(ExceptionConstants.PRODUCT_ALREADY_EXISTS.toString());
		
		productsEntity = sellerRepo.saveAndFlush(ProductsDTO.prepareProductsEntity(productsDTO));
		
		return productsEntity.getProductId();
	}

	@Override
	public List<ProductsDTO> getSellersProduct(String sellerId) throws SellerException {
		
		List<ProductsEntity> products = sellerRepo.findBySellerId(sellerId);
		
		if(products == null || products.isEmpty())
			throw new SellerException(ExceptionConstants.PRODUCT_NOT_EXISTS.toString());
		
		return products.stream()
					.map(ProductsEntity::prepareProductsDTO)
					.collect(Collectors.toList());
	}
	
	@Override
	public List<ProductsDTO> getAllProducts() {
		
		return sellerRepo.getAllProducts()
				.stream()
				.map(ProductsEntity::prepareProductsDTO)
				.collect(Collectors.toList());
	}

	@Override
	public Boolean updateProductDetails(ProductsDTO product) {
		
		Optional<ProductsEntity> ent = sellerRepo.findById(product.getProductId());
		
		if(!ent.isPresent())
			return false;
		
		sellerRepo.saveAndFlush(ProductsDTO.prepareProductsEntity(product, ent.get()));
		
		return true;
	}

	@Override
	public List<ProductsDTO> searchByUserInput(String searchBy) {
		
		return sellerRepo.searchByUserFilter(searchBy.toLowerCase().trim().replaceAll(" +", " "))
				.stream()
				.map(ProductsEntity::prepareProductsDTO)
				.collect(Collectors.toList());
	}
	
	@Override
	public List<ProductsDTO> getProductsByCategory(String categoryName) {
		
		return sellerRepo.findByCategoryName(categoryName.toLowerCase().trim().replaceAll(" +", " ")) 
				.stream()
				.map(ProductsEntity::prepareProductsDTO)
				.collect(Collectors.toList());
	}

	@Override
	public ProductsDTO getProductByProductId(Integer productId) {
		
		return ProductsEntity.prepareProductsDTO(sellerRepo.findById(productId).get());
	}

	@HystrixCommand(fallbackMethod = "getAllSellersOfProductFallback")
	@Override
	public List<SellerDetailsDTO> getAllSellersOfProduct(Integer productId) {
		
		ProductsDTO product = ProductsEntity.prepareProductsDTO(sellerRepo.findById(productId).get());
		
		List<SellerDetailsDTO> sellerDetails = new ArrayList<>();
		
		List<ProductsDTO> products = sellerRepo.findByProductName(product.getProductName())
											.stream()
											.map(ProductsEntity::prepareProductsDTO)
											.collect(Collectors.toList());
		
		List<AccountDTO> sellersAccount = accountClient.getAccountsByAccountType("seller").getBody();
		
		for(ProductsDTO prod: products) {
			
			for(AccountDTO acc: sellersAccount) {
				
				if(prod.getSellerId().equalsIgnoreCase(acc.getUserId())) {
					
					SellerDetailsDTO seller = new SellerDetailsDTO();
					
					seller.setPrice(prod.getEffectivePrice());
					seller.setSellerId(prod.getSellerId());
					seller.setSellerName(acc.getName());
					
					sellerDetails.add(seller);
					
					sellersAccount.remove(acc);
					
					break;
				}
			}
		}
		
		return sellerDetails;
	}
	
	@Override
	public ProductsDTO getRandomProductByCategory(String categoryName) {
		
		return ProductsEntity.prepareProductsDTO(sellerRepo.findOneByCategoryName(categoryName));
	}
	
	public List<SellerDetailsDTO> getAllSellersOfProductFallback(Integer productId) {
		
		return new ArrayList<SellerDetailsDTO>();
	}
}