package com.ecommerce.client;

import java.util.List;

import javax.validation.constraints.NotBlank;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ecommerce.dto.AccountDTO;

@FeignClient("EKART-ACCOUNT-SERVICE")
@RequestMapping("/account")
public interface AccountClient {

	@GetMapping("/{accountType}")
	public ResponseEntity<List<AccountDTO>> getAccountsByAccountType(@NotBlank @PathVariable String accountType);
}
