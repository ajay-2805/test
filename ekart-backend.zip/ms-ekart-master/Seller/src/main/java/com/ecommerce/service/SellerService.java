package com.ecommerce.service;

import java.util.List;

import com.ecommerce.dto.ProductsDTO;
import com.ecommerce.dto.SellerDetailsDTO;
import com.ecommerce.exception.SellerException;

public interface SellerService {
	
	Integer addProduct(ProductsDTO productsDTO) throws SellerException;
	
	Boolean updateProductDetails(ProductsDTO product);
	
	List<ProductsDTO> getSellersProduct(String sellerId) throws SellerException;
	
	List<ProductsDTO> getAllProducts();
	
	List<ProductsDTO> searchByUserInput(String searchBy);

	List<ProductsDTO> getProductsByCategory(String categoryName);
	
	ProductsDTO getProductByProductId(Integer productId);
	
	List<SellerDetailsDTO> getAllSellersOfProduct(Integer productId);
	
	ProductsDTO getRandomProductByCategory(String categoryName);
}