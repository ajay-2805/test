package com.ecommerce.exception;

public enum ExceptionConstants {
	
	SERVER_ERROR("server.error"),
	PRODUCT_ALREADY_EXISTS("product.already.exists"),
	PRODUCT_NOT_EXISTS("product.not.present");

	private final String type;

	private ExceptionConstants(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return this.type;
	}
}
