package com.infy.ekart.address;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EkartAddressMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
