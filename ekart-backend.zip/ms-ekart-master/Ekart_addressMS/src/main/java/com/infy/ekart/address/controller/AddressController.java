package com.infy.ekart.address.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.infy.ekart.address.dto.AddressDTO;
import com.infy.ekart.address.service.AddressService;

@RestController
@CrossOrigin("*")
public class AddressController {
	
	@Autowired
	AddressService service;
	
	@PostMapping("/addAddress")
	public ResponseEntity<Boolean> addAddress(@Valid @RequestBody AddressDTO dto){
		
		boolean flag = service.addAddress(dto);
		return ResponseEntity.ok(flag);
	}
	
	
	@PutMapping("/updateAddress")
	public ResponseEntity<AddressDTO> updateAddress(@RequestBody AddressDTO dto){
		AddressDTO ret = service.updateAddress(dto);
		System.out.println("address dto returned = "+ret);
		return ResponseEntity.ok(ret);
	}
	
	
	@GetMapping("/getAddresses/{userId}")
	public ResponseEntity<List<AddressDTO>> getAddresses(@PathVariable String userId){
		return ResponseEntity.ok(service.getAddresses(userId));
	}
	
	
	@PostMapping("/deleteAddress")
	public ResponseEntity<Boolean> deleteAddress(@RequestBody AddressDTO dto){
		return ResponseEntity.ok(service.deleteAddress(dto));
	}
	
	
}
