package com.infy.ekart.address.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.infy.ekart.address.entity.AddressEntity;

public interface AddressRepository extends JpaRepository<AddressEntity, Integer>{
	
	@Query(value="select addr from AddressEntity addr where addr.user_id = ?1")
	public List<AddressEntity> getAddressByUserId(String userId);
	
}
