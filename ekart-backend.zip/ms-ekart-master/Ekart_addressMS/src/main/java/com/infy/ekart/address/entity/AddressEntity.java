package com.infy.ekart.address.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.infy.ekart.address.dto.AddressDTO;

@Entity
@Table(name="address")
@GenericGenerator(name="addressIdGenerator", strategy = "increment")
public class AddressEntity {
	
	@Id
	@GeneratedValue(generator="addressIdGenerator")
	private int id;
	private String houseNo, street, city, state, user_id;
	private String pincode;
	private String phoneNumber;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	
	public static AddressDTO prepareAddressDTO(AddressEntity entity) {
		
		AddressDTO dto = new AddressDTO();
		dto.setId(entity.getId());
		dto.setHouseNo(entity.getHouseNo());
		dto.setStreet(entity.getStreet());
		dto.setCity(entity.getCity());
		dto.setState(entity.getState());
		dto.setPincode(entity.getPincode());
		dto.setPhoneNumber(entity.getPhoneNumber());
		dto.setUser_id(entity.getUser_id());
		
		
		return dto;
		
	}

}
