package com.infy.ekart.address.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.infy.ekart.address.entity.AddressEntity;

public class AddressDTO {
	
	private int id;
	
	@NotNull
	private String houseNo;
	@NotNull
	private String street;
	@Pattern(regexp = "^[a-zA-Z ]+$", message = "invalid.city")
	private String city;
	private String state;
	private String user_id;
	
	@Pattern(regexp = "[0-9]{6}")
	private String pincode;
	@Pattern(regexp = "[0-9]{10}")
	private String phoneNumber;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	
	public static AddressEntity prepareEntity(AddressDTO dto) {
		AddressEntity entity = new AddressEntity();
		entity.setId(dto.getId());
		entity.setCity(dto.getCity());
		entity.setHouseNo(dto.getHouseNo());
		entity.setPhoneNumber(dto.getPhoneNumber());
		entity.setState(dto.getState());
		entity.setStreet(dto.getStreet());
		entity.setPincode(dto.getPincode());
		entity.setUser_id(dto.getUser_id());
		
		return entity;
	}
	
	
	
}
