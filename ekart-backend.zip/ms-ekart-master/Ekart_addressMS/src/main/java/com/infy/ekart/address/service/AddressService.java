package com.infy.ekart.address.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.infy.ekart.address.dto.AddressDTO;
import com.infy.ekart.address.entity.AddressEntity;
import com.infy.ekart.address.repository.AddressRepository;

@Service
public class AddressService {
	
	@Autowired
	AddressRepository repo;
	
	// TODO: Add loggers
	
	// add address for an existing user
	public Boolean addAddress(AddressDTO dto) {
		repo.save(AddressDTO.prepareEntity(dto));
		return true;
	}
	
	// update existing address, given a user id
	public AddressDTO updateAddress(@RequestBody AddressDTO newAddrDetails) {
		// query and fetch the address given the user id
		// update the entity and save it back to the database
		// need to filter based on addressId as well
		// the repo will give me list of all addresses for a user
		
		String userId = newAddrDetails.getUser_id();
		List<AddressEntity> ls = repo.getAddressByUserId(userId);
		for(AddressEntity address : ls) {
			if(address.getId() == newAddrDetails.getId()) {
				AddressDTO dto = AddressEntity.prepareAddressDTO(address);
				dto.setCity(newAddrDetails.getCity());
				dto.setHouseNo(newAddrDetails.getHouseNo());
				dto.setPhoneNumber(newAddrDetails.getPhoneNumber());
				dto.setPincode(newAddrDetails.getPincode());
				dto.setState(newAddrDetails.getState());
				dto.setStreet(newAddrDetails.getStreet());
				
				repo.save(AddressDTO.prepareEntity(dto));
				return dto;
			}
		}
		return null;
	}
	
	
	// view all shipping addresses that the user has added 
	
	public List<AddressDTO> getAddresses(@PathVariable String userId){
		List<AddressEntity> addrs = repo.getAddressByUserId(userId);
		List<AddressDTO> ret = new ArrayList<>();
		for(AddressEntity ae : addrs) {
			ret.add(AddressEntity.prepareAddressDTO(ae));
		}
		
		return ret;
	}
	
	public boolean deleteAddress(AddressDTO dto) {
		List<AddressEntity> addrs = repo.getAddressByUserId(dto.getUser_id());
		for(AddressEntity ae : addrs) {
			if(ae.getId() == dto.getId() && ae.getUser_id().equals(dto.getUser_id())) {
				repo.delete(ae);
				break;
			}
		}
		return true;
	}
	
	
	
}
