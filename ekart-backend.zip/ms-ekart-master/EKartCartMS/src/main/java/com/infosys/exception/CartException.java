package com.infosys.exception;



public class CartException extends Exception  {
	
	private static final long serialVersionUID = 1L;
	
	public CartException() {
		super();
	}
	public CartException(String errors) {
		super(errors);
	}
	
}
