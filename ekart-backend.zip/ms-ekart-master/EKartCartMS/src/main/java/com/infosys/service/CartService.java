package com.infosys.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.infosys.dto.CartDTO;
import com.infosys.exception.CartException;

public interface CartService {

	public String addProductToCart(@Valid @RequestBody CartDTO cartDTO) throws CartException;
	public CartDTO updateProductQuantity(@Valid @PathVariable("cartId") String cartId,
			@Valid @RequestParam("quantity") int quantity, 
			@Valid @RequestParam("totalPrice") long totalPrice) throws CartException ;
	public Boolean removeProduct(@Valid @PathVariable("cartId") String cartId) throws CartException;
	
	public List<CartDTO> getAllProducts(@Valid String userId) throws CartException;
	
	public  boolean  isCartExist(String userId,int productId);
}
