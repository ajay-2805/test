package com.infosys.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dto.CartDTO;
import com.infosys.exception.CartException;
import com.infosys.service.CartService;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/cart")
@CrossOrigin
@Validated
public class CartRestController {
	
	@Autowired
	public CartService cartService;
	private static Logger logger = LoggerFactory.getLogger(CartRestController.class);
	
//	 @PathVariable("userId") String userId, @Valid @PathVariable("productId") String productId,
//		@Valid @PathVariable("sellerId") String sellerId,@Valid @RequestParam("quantity") int quantity,
//		@Valid @RequestParam("dateOfPurchase") int dateOfPurchase, @Valid @RequestParam("quantity") int quantity
	
	@PostMapping("/product")
	public ResponseEntity<String> addProductToCart(@Valid @RequestBody CartDTO cartDTO) throws CartException {
		String response = "";
		logger.info("inside add Product method:");	
		response = cartService.addProductToCart(cartDTO);
		logger.info("inside add cart method: "+ response);
		return ResponseEntity.ok(response);
	}
	
	@PutMapping("/product/{cartId}")
	public ResponseEntity<CartDTO> updateProductQuantity(@Valid @PathVariable("cartId") String cartId,
			@Valid @RequestParam("quantity") int quantity,  @Valid @RequestParam("totalPrice") long totalPrice) throws CartException {
		CartDTO response = new CartDTO();
		logger.info("inside add Product method:");	
		response = cartService.updateProductQuantity(cartId, quantity, totalPrice);
		logger.info("inside add cart method: "+ response);
		return ResponseEntity.ok(response);
		
		
	}
	
	@DeleteMapping("/product/{cartId}")
	public ResponseEntity<Boolean> removeProduct(@Valid @PathVariable("cartId") String cartId) throws CartException {
		Boolean response = false;
		logger.info("inside add Product method:");	
		response = cartService.removeProduct(cartId);
		logger.info("inside add cart method: "+ response);
		return ResponseEntity.ok(response);
		
		
	}
	
	@GetMapping("/products/{userId}")
	public  List<CartDTO>  getAllProducts(@Valid @PathVariable("userId") String userId) throws CartException {
		List<CartDTO> cartDTOList = new ArrayList<CartDTO>();
		cartDTOList = cartService.getAllProducts(userId);
		return cartDTOList;
		
	}
}
