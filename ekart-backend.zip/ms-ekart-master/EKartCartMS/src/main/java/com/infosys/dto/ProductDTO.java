package com.infosys.dto;

public class ProductDTO {

}
