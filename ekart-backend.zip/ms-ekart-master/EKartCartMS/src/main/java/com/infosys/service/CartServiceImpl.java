package com.infosys.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.infosys.dto.CartDTO;
import com.infosys.entity.CartEntity;
import com.infosys.exception.CartException;
import com.infosys.exception.ExceptionConstants;
import com.infosys.repository.CartRepository;
import com.infosys.service.CartService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class CartServiceImpl implements CartService {
	
	private static Logger logger = LoggerFactory.getLogger(CartServiceImpl.class);
	
	@Autowired
	private CartRepository cartRepository;

	@Override
	public String addProductToCart(@Valid @RequestBody CartDTO cartDTO) throws CartException {
		String cartId = null;
		long totalPrice =0;
		try {
			if(!cartDTO.equals(null)) {
					if(!isCartExist(cartDTO.getUserId(),cartDTO.getProductId())) {
						totalPrice = Math.round(cartDTO.getPrice()*((100-cartDTO.getDiscount())/100));
						cartDTO.setTotalPrice(totalPrice);
						CartEntity cart = CartDTO.prepareEntity(cartDTO);
						CartEntity newCart = cartRepository.save(cart);
						CartDTO newCartDTO = CartEntity.prepareDTO(newCart);
						cartId = newCartDTO.getCartId();		
					} else {
						CartEntity cart = cartRepository.findCartByProductId(cartDTO.getUserId(),cartDTO.getProductId());
						int newQuant = cart.getQuantity()+1;
						long newPrice =Math.round(newQuant*cartDTO.getPrice()*((100-cartDTO.getDiscount())/100));
						CartDTO updatedCart = updateProductQuantity(cart.getCartId(),newQuant,newPrice);
						cartId = updatedCart.getCartId();
					}
							
				}
		
		} catch (Exception e) {
			logger.info("In log Exception ");
			logger.error(e.getMessage(),e);
		}
		return cartId;
	}	
	
	@Override
	public CartDTO updateProductQuantity(@Valid @PathVariable("cartId") String cartId,
			@Valid @RequestParam("quantity") int quantity, 
			@Valid @RequestParam("totalPrice") long totalPrice) throws CartException {
			
			Optional<CartEntity> cart = cartRepository.findById(cartId);
			CartDTO cartDTO = CartEntity.prepareDTO(cart.get());
			try {
				if(cartDTO != null) {
					cartDTO.setQuantity(quantity);
					cartDTO.setTotalPrice(totalPrice);
					CartEntity newCart = cartRepository.saveAndFlush(CartDTO.prepareEntity(cartDTO));
					return CartEntity.prepareDTO(newCart);
				}
			throw new CartException(ExceptionConstants.CART_ALREADY_EXISTS.toString()); 
			} catch (CartException e) {
				logger.info("In log Exception ");
				logger.error(e.getMessage(),e);
			}
			return new CartDTO();
	
	}	

	@Override
	public Boolean removeProduct(@Valid @PathVariable("cartId") String cartId) throws CartException {
		Optional<CartEntity> cart = cartRepository.findById(cartId);
		CartDTO cartDTO = CartEntity.prepareDTO(cart.get());
		try {
			 if(cartDTO != null) {
				 cartRepository.deleteById(cartId);
				 return true;
			 }
			 throw new CartException(ExceptionConstants.CART_ALREADY_EXISTS.toString()); 
		} catch (CartException e) {
			logger.info("In log Exception ");
			logger.error(e.getMessage(),e);
		}
		return false;	
		
	}
	
	@Override
	public  List<CartDTO>  getAllProducts(@Valid @PathVariable("userId") String userId) throws CartException {
		List<CartEntity>  cartList = cartRepository.findAllCartEntity(userId);
		List<CartDTO> cartDTOList = new ArrayList<CartDTO>();
		for(CartEntity cart: cartList) {
			CartDTO cartDTO = CartEntity.prepareDTO(cart);
			cartDTOList.add(cartDTO);
		}
		return cartDTOList;
				
	}
	
	@Override
	public  boolean  isCartExist(String userId, int productId){
		CartEntity cart = cartRepository.findCartByProductId(userId,productId);
		boolean  flag = false;
		if(cart !=null) {
			flag = true;
		}
		return flag;
	}

}
