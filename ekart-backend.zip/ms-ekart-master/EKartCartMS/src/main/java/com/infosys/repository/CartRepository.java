package com.infosys.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.infosys.entity.CartEntity;

public interface CartRepository  extends JpaRepository<CartEntity, String>{
	
	 @Query("SELECT CE FROM CartEntity CE WHERE CE.userId = ?1")
	 List<CartEntity>  findAllCartEntity(String userId);
	 
	 @Query("SELECT CE FROM CartEntity CE WHERE CE.userId = ?1 AND CE.productId = ?2")
	 CartEntity findCartByProductId(String userId, int productId);

}
