package com.infosys.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.infosys.dto.CartDTO;
import com.sun.istack.NotNull;

@Entity
@Table(name= "carttable")
@GenericGenerator (name = "generatorCartId", strategy = "com.infosys.utility.CartIdGenerator")
public class CartEntity {

	@Id
	@GeneratedValue(generator = "generatorCartId")
	@Column(name="cart_id")
	private String	cartId;
	
	@Column(name="user_id")
	private String	userId;
	
	@Column(name="product_id")
	private int	productId;
	
	@Column(name="seller_id")
	private String	sellerId;
	
	@Column(name="product_name")
	private String productName;

	private int	quantity;
	
	@Column(name="date_of_purchase")
	private LocalDate	dateOfPurchase;
	
	@Column(name="date_of_expiry")
	private LocalDate	dateOfExpiry;

	private long price;

	private float discount;
	
	@Column(name="total_price")
	private long	totalPrice;
	
	public CartEntity() {
		super();
		// TODO Auto-generated constructor stub
	}



	public CartEntity(String cartId, String userId, int productId, String sellerId, String productName, int quantity,
			LocalDate dateOfPurchase, LocalDate dateOfExpiry, long price, float discount, long totalPrice) {
		super();
		this.cartId = cartId;
		this.userId = userId;
		this.productId = productId;
		this.sellerId = sellerId;
		this.productName = productName;
		this.quantity = quantity;
		this.dateOfPurchase = dateOfPurchase;
		this.dateOfExpiry = dateOfExpiry;
		this.price = price;
		this.discount = discount;
		this.totalPrice = totalPrice;
	}



	public String getCartId() {
		return cartId;
	}

	public void setCartId(String cartId) {
		this.cartId = cartId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public LocalDate getDateOfPurchase() {
		return dateOfPurchase;
	}

	public void setDateOfPurchase(LocalDate dateOfPurchase) {
		this.dateOfPurchase = dateOfPurchase;
	}

	public LocalDate getDateOfExpiry() {
		return dateOfExpiry;
	}

	public void setDateOfExpiry(LocalDate dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}

	public long getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(long totalPrice) {
		this.totalPrice = totalPrice;
	}	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}
	public float getDiscount() {
		return discount;
	}
	public void setDiscount(float discount) {
		this.discount = discount;
	}

	public static CartDTO prepareDTO(CartEntity cartEntity)
	{
		return new CartDTO(cartEntity.getCartId(), cartEntity.getUserId(), cartEntity.getProductId(), cartEntity.getSellerId(), 
				cartEntity.getProductName(),cartEntity.getQuantity(),cartEntity.getDateOfPurchase(),cartEntity.getDateOfExpiry()
				, cartEntity.getPrice(), cartEntity.getDiscount(), cartEntity.getTotalPrice());
	}


}
