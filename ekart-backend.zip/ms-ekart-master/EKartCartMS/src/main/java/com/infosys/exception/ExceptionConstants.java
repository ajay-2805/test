package com.infosys.exception;

public enum ExceptionConstants {
	SERVER_ERROR("server.error"),
	USER_NOT_FOUND("user.not.found"),
	CART_ALREADY_EXISTS("cart.already.exists");
	
	private final String type;
	private ExceptionConstants(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return this.type;
	}
}
