package com.infosys.EKartCartMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EKartCartMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
