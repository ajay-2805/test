package com.ekart.DTO;

import java.time.LocalDate;

public class OrderDTO {

	int orderId;
	
	int buyerId;
	
	LocalDate orderDate;
	
	LocalDate estimatedDeliverDate;
	
	LocalDate deliverDate;
	
	int productId;
	
	int sellerId;
	
	int quantity;
	
	String address;
	
	long cardNo;
	
	String status;
	
	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public LocalDate getEstimatedDeliverDate() {
		return estimatedDeliverDate;
	}

	public void setEstimatedDeliverDate(LocalDate estimatedDeliverDate) {
		this.estimatedDeliverDate = estimatedDeliverDate;
	}

	public LocalDate getDeliverDate() {
		return deliverDate;
	}

	public void setDeliverDate(LocalDate deliverDate) {
		this.deliverDate = deliverDate;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}
	
	public int getSellerId() {
		return sellerId;
	}
	
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public long getCardNo() {
		return cardNo;
	}
	
	public void setCardNo(long cardNo) {
		this.cardNo = cardNo;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
}
