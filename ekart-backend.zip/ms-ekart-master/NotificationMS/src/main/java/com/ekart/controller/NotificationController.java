package com.ekart.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.ekart.DTO.CartDTO;
import com.ekart.DTO.NotificationDTO;
import com.ekart.DTO.OrderDTO;
import com.ekart.service.NotificationService;

@RestController
@CrossOrigin
public class NotificationController {
	
	@Autowired
	NotificationService service;
	
	@GetMapping(path="/getOrderNotifications/{id}")
	public List<NotificationDTO> getOrderNotifications(@PathVariable("id") int id){
		List<OrderDTO> orderDTOs = service.getAllOrders(id);
		
		List<NotificationDTO> notificationDTOs = new ArrayList<>();
		for (OrderDTO orderDTO : orderDTOs) {
			NotificationDTO dto = new NotificationDTO();
			String message = "";
			
			dto.setOrderId(orderDTO.getOrderId());
			dto.setStatus(orderDTO.getStatus());
			dto.setOrderDate(orderDTO.getOrderDate());
			dto.setEstimatedDeliverDate(orderDTO.getEstimatedDeliverDate());
			dto.setDeliverDate(orderDTO.getDeliverDate());
			dto.setQuantity(orderDTO.getQuantity());
			dto.setAddress(orderDTO.getAddress());

			if(orderDTO.getStatus().equalsIgnoreCase("ordered")) {
				message = "Your order having order id: "+ orderDTO.getOrderId() + " is placed successfully.";
				dto.setMessage(message);
			}else if(orderDTO.getStatus().equalsIgnoreCase("delivered")) {
				message = "Your order having order id: "+ orderDTO.getOrderId() + " is delivered successfully.";
				dto.setMessage(message);
			}
			notificationDTOs.add(dto);
		}
		return notificationDTOs;
	}
	
	@GetMapping(path="/getCartNotifications/{id}")
	public List<NotificationDTO> getCartNotifications(@PathVariable("id") int id){
		List<CartDTO> cartDTOs = service.getAllCartItems(id);
		
		List<NotificationDTO> notificationDTOs = new ArrayList<>();
		for (CartDTO cartDTO : cartDTOs) {
			NotificationDTO dto = new NotificationDTO();
			String message = "";
			if(cartDTO.getDiscount() != 0) {
				dto.setProductId(cartDTO.getProductId());
				dto.setProductName(cartDTO.getProductName());
				dto.setPrice(cartDTO.getPrice());
				dto.setDiscount(cartDTO.getDiscount());
				dto.setDiscountedPrice(cartDTO.getPrice() * (100-cartDTO.getDiscount())/100);
				dto.setProductId(cartDTO.getProductId());
				dto.setProductId(cartDTO.getProductId());
				
				message = "The price of your cart item: "+ cartDTO.getProductName() + " has changed";
				dto.setMessage(message);
			}
			notificationDTOs.add(dto);
		}
		return notificationDTOs;
	}

}
