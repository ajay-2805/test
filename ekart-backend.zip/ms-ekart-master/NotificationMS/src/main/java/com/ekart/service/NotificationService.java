package com.ekart.service;

import java.sql.Wrapper;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.client.RestTemplate;

import com.ekart.DTO.CartDTO;
import com.ekart.DTO.OrderDTO;



@Service
public class NotificationService {
	
	@Value("${orderMS_URL}")
	String orderMS_URL;
	
	@Value("${cartMS_URL}")
	String cartMS_URL;
	
	public List<OrderDTO> getAllOrders(int id){
		List<OrderDTO> orderDTOs = new RestTemplate().exchange(orderMS_URL+"/"+id, HttpMethod.GET, null,
			    new ParameterizedTypeReference<List<OrderDTO>>() {}).getBody();
		return orderDTOs;
	}
	
	public List<CartDTO> getAllCartItems(int id){
		List<CartDTO> cartDTOs = new RestTemplate().exchange(cartMS_URL+"/"+id, HttpMethod.GET, null,
			    new ParameterizedTypeReference<List<CartDTO>>() {}).getBody();
		return cartDTOs;
	}
}
