package com.ecommerce.exception;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.ecommerce.dto.ErrorMessage;

@RestControllerAdvice
public class ExceptionControllerAdvice {

	@Autowired
    private Environment environment;
	
	@ExceptionHandler(Exception.class)
	public String exceptionHandler(Exception ex) {
		
		ex.printStackTrace();
		return ex.getMessage();
	}
	
	@ExceptionHandler(UserException.class)
	public ResponseEntity<ErrorMessage> exceptionHandler(UserException e) {
		
		ErrorMessage em = new ErrorMessage();
		em.setMessage(environment.getProperty(e.getMessage()));
		
		
		  if(e.getMessage().contains("booking.already.exists")) 
			  return new ResponseEntity<ErrorMessage>(em, HttpStatus.NOT_FOUND);
		 
		return new ResponseEntity<ErrorMessage>(em, HttpStatus.OK);
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorMessage> invalidMethodArgumentExceptionHandler(MethodArgumentNotValidException e) {
		
		String msg = e.getBindingResult()
				.getAllErrors()
				.stream()
				.map(ObjectError::getDefaultMessage)
				.collect(Collectors.joining(", "));
		
		ErrorMessage em = new ErrorMessage();
		
		em.setMessage(msg);
		
		return new ResponseEntity<ErrorMessage>(em, HttpStatus.BAD_REQUEST);
	}
}
