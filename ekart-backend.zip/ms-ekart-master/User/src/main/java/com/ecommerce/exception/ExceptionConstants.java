package com.ecommerce.exception;

public enum ExceptionConstants {
	
	SERVER_ERROR("server.error");

	private final String type;

	private ExceptionConstants(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return this.type;
	}
}
