package com.ecommerce.dto;

public class CartDTO {

	private String userId;
	private String sellerId;
	private String productName;

	private Integer productId;
	private Integer quantity;

	private Long price;

	private Float discount;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Long getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price.longValue();
	}

	public Float getDiscount() {
		return discount;
	}

	public void setDiscount(Integer discount) {
		this.discount = Float.valueOf(discount);
	}

}
