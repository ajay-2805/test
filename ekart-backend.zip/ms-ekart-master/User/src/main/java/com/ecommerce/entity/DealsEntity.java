package com.ecommerce.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

import com.ecommerce.dto.DealsDTO;

@Entity
@GenericGenerator(name = "idGen", strategy = "increment")
public class DealsEntity {

	@Id
	@GeneratedValue(generator = "idGen")
	private int dealId;
	private int productId;
	private int discount;
	private String dealMessage;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public String getDealMessage() {
		return dealMessage;
	}

	public void setDealMessage(String dealMessage) {
		this.dealMessage = dealMessage;
	}

	public int getDealId() {
		return dealId;
	}
	
	public static DealsDTO prepateDTO(DealsEntity deals) {
		
		DealsDTO dealsDTO = new DealsDTO();
		
		dealsDTO.setDealId(deals.getDealId());
		dealsDTO.setDealMessage(deals.getDealMessage());
		dealsDTO.setDiscount(deals.getDiscount());
		dealsDTO.setProductId(deals.getProductId());
		
		return dealsDTO;
	}
}
