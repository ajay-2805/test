package com.ecommerce.dto;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class OrderDTO {

	Integer orderId;
	Integer productId;
	Integer quantity;

	LocalDate orderDate;
	LocalDate deliverDate;

	String address;
	String status;
	String buyerId;
	String sellerId;

	Long cardNo;

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public LocalDate getDeliverDate() {
		return deliverDate;
	}

	public void setDeliverDate(LocalDate deliverDate) {
		this.deliverDate = deliverDate;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public Long getCardNo() {
		return cardNo;
	}

	public void setCardNo(Long cardNo) {
		this.cardNo = cardNo;
	}
	
	public static List<OrderDTO> returnOrders() {
		
		List<OrderDTO> orders = new ArrayList<>();
		
		/*
		 * OrderDTO o1 = new OrderDTO(); o1.setProductId(1);
		 * 
		 * OrderDTO o2 = new OrderDTO(); o2.setProductId(6);
		 * 
		 * OrderDTO o3 = new OrderDTO(); o3.setProductId(5);
		 * 
		 * OrderDTO o4 = new OrderDTO(); o4.setProductId(8);
		 * 
		 * orders.add(o1); orders.add(o2); orders.add(o3); orders.add(o4);
		 */
		
		return orders;
	}

	@Override
	public String toString() {
		return "OrderDTO [orderId=" + orderId + ", productId=" + productId + ", quantity=" + quantity + ", orderDate="
				+ orderDate + ", deliverDate=" + deliverDate + ", address=" + address + ", status=" + status
				+ ", buyerId=" + buyerId + ", sellerId=" + sellerId + ", cardNo=" + cardNo + "]";
	}
}
