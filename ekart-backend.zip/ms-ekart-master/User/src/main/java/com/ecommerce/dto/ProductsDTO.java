package com.ecommerce.dto;

public class ProductsDTO {

	private Integer productId;
	private String sellerId;
	private String productName;
	private String categoryName;
	private Float price;
	private Integer discount;
	private String shortDescription;
	private String description;
	private Float effectivePrice;
	private Integer quantitiesSold;
	private Double totalEarned;

	@Override
	public String toString() {
		return "ProductsDTO [productId=" + productId + ", sellerId=" + sellerId + ", productName=" + productName
				+ ", categoryName=" + categoryName + ", price=" + price + ", discount=" + discount
				+ ", shortDescription=" + shortDescription + ", description=" + description + "]";
	}
	
	public Float getEffectivePrice() {
		return effectivePrice;
	}

	public void setEffectivePrice(Float effectivePrice) {
		this.effectivePrice = effectivePrice;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId.trim().replaceAll(" +", " ");
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName.trim().replaceAll(" +", " ");
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName.trim().replaceAll(" +", " ");
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Integer getDiscount() {
		return discount;
	}

	public void setDiscount(Integer discount) {
		this.discount = discount;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription.trim().replaceAll(" +", " ");
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description.trim().replaceAll(" +", " ");
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Integer getQuantitiesSold() {
		return quantitiesSold;
	}

	public void setQuantitiesSold(Integer quantitiesSold) {
		this.quantitiesSold = quantitiesSold;
	}

	public Double getTotalEarned() {
		return totalEarned;
	}

	public void setTotalEarned(Double totalEarned) {
		this.totalEarned = totalEarned;
	}
}