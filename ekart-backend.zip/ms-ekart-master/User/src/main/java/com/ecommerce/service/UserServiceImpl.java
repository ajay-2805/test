package com.ecommerce.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.client.CartClient;
import com.ecommerce.client.SellerClient;
import com.ecommerce.dto.CartDTO;
import com.ecommerce.dto.DealsDTO;
import com.ecommerce.dto.OrderDTO;
import com.ecommerce.dto.ProductsDTO;
import com.ecommerce.entity.DealsEntity;
import com.ecommerce.repository.UserRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepo;
	
	@Autowired
	SellerClient sellerClient;
	
	@Autowired
	CartClient cartClient;
	
	@HystrixCommand(fallbackMethod = "getProductsWithDealFallback")
	@Override
	public List<ProductsDTO> getProductsWithDeal() {
		
		List<ProductsDTO> products = new ArrayList<>();

		List<DealsDTO> dealProducts = userRepo.findAll()
											.stream()
											.map(DealsEntity::prepateDTO)
											.collect(Collectors.toList());
		
		for(DealsDTO deal: dealProducts) {
			
			ProductsDTO product = sellerClient.getByProductId(deal.getProductId()).getBody();
			product.setDiscount(deal.getDiscount());
			
			if(updateProductsDeals(product))
				products.add(sellerClient.getByProductId(deal.getProductId()).getBody());
		}
		
		return products;
	}

	@HystrixCommand(fallbackMethod = "getProductsWithDealFallback")
	@Override
	public List<ProductsDTO> getSuggestions() {
		
		List<OrderDTO> orders = OrderDTO.returnOrders();
		
		List<ProductsDTO> products = new ArrayList<>();
		
		for(OrderDTO order: orders) {
			
			products.add(sellerClient.getByProductId(order.getProductId()).getBody());
		}
		
		return getProductsSuggestions(products);
	}
	
	private List<ProductsDTO> getProductsSuggestions(List<ProductsDTO> products) {
		
		List<ProductsDTO> suggestedProducts = new ArrayList<>();
		
		Set<String> categorySet = new HashSet<>();
		int count = 0;
		
		for(ProductsDTO prod: products) {
			
			categorySet.add(prod.getCategoryName());
			
			if(categorySet.size() > count) 
				count++;
			
			if(count > 4)
				break;
		}
		
		int diff = 4 - count;
		
		List<String> suggestedCategories = new ArrayList<>(categorySet);
		
		for(int i = 0; i < suggestedCategories.size(); i++) {
			
			suggestedProducts.add(sellerClient.getRandomProducyByCategoryName(suggestedCategories.get(i)).getBody());
			
			if(i < diff) {
				i--;
				--diff;
			}
		}
		
		if(suggestedCategories.isEmpty()) {
			
			String[] categories = {"Mobile", "Laptop", "Watch", "Camera"};
			
			for(int i = 0; i < categories.length; i++) {
				
				suggestedProducts.add(sellerClient.getRandomProducyByCategoryName(categories[i]).getBody());
			}
		}
		
		return suggestedProducts;
	}

	@HystrixCommand(fallbackMethod = "updateProductsDealsFallback")
	private boolean updateProductsDeals(ProductsDTO product) {
		
		return sellerClient.updateProductDetails(product).getBody();
	}
	
	@SuppressWarnings("unused")
	private boolean updateProductsDealsFallback(ProductsDTO product) {
		
		return false;
	}

	@HystrixCommand(fallbackMethod = "addProductToCartFallback")
	@Override
	public String addProductToCart(Integer productId, String userId) {
		
		CartDTO cart = new CartDTO();
		
		ProductsDTO product = sellerClient.getByProductId(productId).getBody();
		
		cart.setSellerId(product.getSellerId());
		cart.setDiscount(product.getDiscount());
		cart.setPrice(product.getPrice());
		cart.setProductId(product.getProductId());
		cart.setProductName(product.getProductName());
		cart.setQuantity(1);
		cart.setUserId(userId);
		
		return cartClient.addProductToCart(cart).getBody();
	}
	
	public String addProductToCartFallback(Integer productId, String userId) {
		
		return "Failed to add product to cart";
	}
	
	public List<ProductsDTO> getProductsWithDealFallback() {
		
		return new ArrayList<ProductsDTO>();
	}
}