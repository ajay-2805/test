package com.ecommerce.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ecommerce.dto.OrderDTO;

@FeignClient("ECOMORDERS")
public interface OrderClient {

	@GetMapping("/buyer/{buyerId}")
	public ResponseEntity<List<OrderDTO>> getAllBuyersOrders(@PathVariable String buyerId);
}
