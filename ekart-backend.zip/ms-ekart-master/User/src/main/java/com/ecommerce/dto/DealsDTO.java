package com.ecommerce.dto;

import com.ecommerce.entity.DealsEntity;

public class DealsDTO {

	private int dealId;
	private int productId;
	private int discount;
	private String dealMessage;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public String getDealMessage() {
		return dealMessage;
	}

	public void setDealMessage(String dealMessage) {
		this.dealMessage = dealMessage;
	}

	public int getDealId() {
		return dealId;
	}

	public void setDealId(int dealId) {
		this.dealId = dealId;
	}

	public static DealsEntity prepateDTO(DealsDTO deals) {

		DealsEntity dealsEnt = new DealsEntity();
		
		dealsEnt.setDealMessage(deals.getDealMessage());
		dealsEnt.setDiscount(deals.getDiscount());
		dealsEnt.setProductId(deals.getProductId());

		return dealsEnt;
	}
}
