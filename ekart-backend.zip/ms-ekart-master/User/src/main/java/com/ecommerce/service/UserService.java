package com.ecommerce.service;

import java.util.List;

import com.ecommerce.dto.CartDTO;
import com.ecommerce.dto.ProductsDTO;

public interface UserService {
	
	List<ProductsDTO> getProductsWithDeal();
	
	List<ProductsDTO> getSuggestions();
	
	String addProductToCart(Integer productId, String userId);
}