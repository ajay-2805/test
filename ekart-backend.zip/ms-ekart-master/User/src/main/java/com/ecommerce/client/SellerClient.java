package com.ecommerce.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ecommerce.dto.ProductsDTO;

@FeignClient("ECOMSELLER")
@RequestMapping("/seller/products")
public interface SellerClient {

	@PutMapping
	public ResponseEntity<Boolean> updateProductDetails(@RequestBody ProductsDTO product);
	
	@GetMapping("/product/{productId}")
	public ResponseEntity<ProductsDTO> getByProductId(@PathVariable Integer productId);
	
	@GetMapping("/category/random/{categoryName}")
	public ResponseEntity<ProductsDTO> getRandomProducyByCategoryName(@PathVariable String categoryName);
}
