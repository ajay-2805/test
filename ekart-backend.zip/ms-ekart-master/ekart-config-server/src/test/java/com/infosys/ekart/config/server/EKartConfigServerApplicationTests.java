package com.infosys.ekart.config.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EKartConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
