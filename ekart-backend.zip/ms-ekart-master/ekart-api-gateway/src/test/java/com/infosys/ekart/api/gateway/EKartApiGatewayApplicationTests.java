package com.infosys.ekart.api.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EKartApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
