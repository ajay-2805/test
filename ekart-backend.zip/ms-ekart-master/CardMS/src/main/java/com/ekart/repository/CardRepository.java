package com.ekart.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ekart.entity.CardEntity;

public interface CardRepository extends JpaRepository<CardEntity, Integer> {

	@Query(value = "select c from CardEntity c where c.user_id = ?1")
	public List<CardEntity> getAllCardsById(String userId);
}
