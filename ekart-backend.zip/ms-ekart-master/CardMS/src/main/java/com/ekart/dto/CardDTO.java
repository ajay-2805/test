package com.ekart.dto;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.ekart.entity.CardEntity;

public class CardDTO {
	private int id;
	@NotNull
	private String type;
	@NotNull
	private String cardNumber;
	@NotNull
	private String provider;
	@NotNull
	private String userId;
	@NotNull
	private String name;
	@NotNull
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate expiryDate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getProvider() {
		return provider;
	}
	public void setProvider(String provider) {
		this.provider = provider;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public static CardEntity prepareEntity(CardDTO dto) {
		CardEntity entity = new CardEntity();
		entity.setId(dto.getId());
		entity.setType(dto.getType());
		entity.setCard_number(dto.getCardNumber());
		entity.setProvider(dto.getProvider());
		entity.setUser_id(dto.getUserId());
		entity.setName(dto.getName());
		entity.setExpiry_date(dto.getExpiryDate());
		return entity;
	}
}
