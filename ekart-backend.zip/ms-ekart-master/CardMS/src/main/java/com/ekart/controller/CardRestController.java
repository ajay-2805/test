package com.ekart.controller;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ekart.dto.CardDTO;
import com.ekart.exception.EKartException;
import com.ekart.service.CardService;

@RestController
@CrossOrigin
public class CardRestController {
	
	@Autowired
	CardService service;
	
	private static Logger log = LoggerFactory.getLogger(CardRestController.class);
	
	@PostMapping(path = "/addcard")
	public ResponseEntity<Boolean> addcard(@Valid @RequestBody CardDTO cardDTO, Errors error) throws Exception{
		if(error.hasErrors()) {
			String errorString = error.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.joining(","));
			log.error("Input valiation error: "+ errorString);
			throw new Exception(errorString);
		}
		return ResponseEntity.ok(service.addcard(cardDTO));
	}
	
	@GetMapping(path = "/getAllCards/{userId}")
	public ResponseEntity<List<CardDTO>> getAllCardsById(@PathVariable("userId") String userId) throws EKartException{
		return ResponseEntity.ok(service.getAllCardsById(userId));
	}
	
	@DeleteMapping(path = "/deleteCard/{id}")
	public ResponseEntity<Boolean> deleteCardById(@PathVariable("id") int id){
		return ResponseEntity.ok(service.deleteCardById(id));
	}
}
