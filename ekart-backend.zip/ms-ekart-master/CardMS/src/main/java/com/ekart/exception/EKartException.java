package com.ekart.exception;

public class EKartException extends Exception {
	public EKartException() {
		super();
	}
	public EKartException(String message) {
		super(message);
	}
}
