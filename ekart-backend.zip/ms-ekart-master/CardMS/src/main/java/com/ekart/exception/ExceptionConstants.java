package com.ekart.exception;
public enum ExceptionConstants {
	SERVER_ERROR("server.error"),
	NO_CARD_FOUND("card.not.found");
	private final String type;
	private ExceptionConstants(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return this.type;
	}
}