package com.ekart.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.ekart.dto.CardDTO;

@Entity
@Table(name = "card")
@GenericGenerator(name = "cardIdGen", strategy = "increment")
public class CardEntity {
	@Id
	@GeneratedValue(generator = "cardIdGen")
	private int id;
	private String type;
	private String card_number;
	private String provider;
	private String user_id;
	private String name;
	private LocalDate expiry_date;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCard_number() {
		return card_number;
	}
	public void setCard_number(String card_number) {
		this.card_number = card_number;
	}
	public String getProvider() {
		return provider;
	}
	public void setProvider(String provider) {
		this.provider = provider;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getExpiry_date() {
		return expiry_date;
	}
	public void setExpiry_date(LocalDate expiry_date) {
		this.expiry_date = expiry_date;
	}
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public static CardDTO prepareCardDTO(CardEntity entity) {
		CardDTO dto = new CardDTO();
		dto.setId(entity.getId());
		dto.setType(entity.getType());
		dto.setCardNumber(entity.getCard_number());
		dto.setProvider(entity.getProvider());
		dto.setUserId(entity.getUser_id());
		dto.setName(entity.getName());
		dto.setExpiryDate(entity.getExpiry_date());
		return dto;
	}
}
