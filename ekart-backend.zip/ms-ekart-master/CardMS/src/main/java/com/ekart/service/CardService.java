package com.ekart.service;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.ekart.dto.CardDTO;
import com.ekart.entity.CardEntity;
import com.ekart.exception.EKartException;
import com.ekart.repository.CardRepository;

@Service
public class CardService {
	
	@Autowired
	CardRepository repository;
	
	private static Logger log = LoggerFactory.getLogger(CardService.class);
	
	public Boolean addcard(CardDTO cardDTO){
		repository.save(CardDTO.prepareEntity(cardDTO));
		log.error("Card details saved for userid: "+ cardDTO.getName());
		return true;
	}
	
	public List<CardDTO> getAllCardsById(String userId) throws EKartException{
		List<CardEntity> cardEntities = repository.getAllCardsById(userId);
		if(!cardEntities.isEmpty()) {
			List<CardDTO> cardDTOs = cardEntities.stream().map(entity -> CardEntity.prepareCardDTO(entity))
					.collect(Collectors.toList());
			return cardDTOs;
		}else {
			log.error("Card not found for userId: "+ userId);
			throw new EKartException(com.ekart.exception.ExceptionConstants.NO_CARD_FOUND.toString());
		}
		
	}
	
	public Boolean deleteCardById(@PathVariable("id") int id){
		repository.deleteById(id);
		return true;
	}
}
