package com.infosys.ekart.account.exception;

import java.util.stream.Collectors;

import javax.validation.ConstraintViolationException;

import org.hibernate.validator.internal.engine.path.PathImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.infosys.ekart.account.dto.ErrorMessage;

@RestControllerAdvice
public class ExceptionControllerAdvice {
	
	@Autowired
	Environment env;	
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorMessage> exceptionHandler(MethodArgumentNotValidException ex) {
		var errorMessage = new ErrorMessage();
		errorMessage.setMessage(
				ex.getBindingResult().getFieldErrors().stream().map(e -> 
				String.format("%s %s", e.getField(), e.getDefaultMessage()))
				.collect(Collectors.joining(", ")));
		return new ResponseEntity<>(errorMessage, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<ErrorMessage> exceptionHandler(ConstraintViolationException ex) {
		var errorMessage = new ErrorMessage();
		errorMessage.setMessage(
				ex.getConstraintViolations().stream().map(e -> 
				String.format("%s %s", ((PathImpl)e.getPropertyPath()).getLeafNode().getName(), 
						e.getMessage())).collect(Collectors.joining(", ")));
		return new ResponseEntity<>(errorMessage, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(EKartException.class)
	public ResponseEntity<ErrorMessage> exceptionHandler(EKartException ex) {
		var errorMessage = new ErrorMessage();
		errorMessage.setMessage(env.getProperty(ex.getMessage()));
		return new ResponseEntity<>(errorMessage, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorMessage> exceptionHandler(Exception ex) {
		var errorMessage = new ErrorMessage();
		errorMessage.setMessage(env.getProperty(ExceptionConstants.SERVER_ERROR.toString()));
		return new ResponseEntity<>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
	}	

}
