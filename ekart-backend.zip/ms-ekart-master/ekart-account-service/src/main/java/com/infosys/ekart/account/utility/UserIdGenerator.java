package com.infosys.ekart.account.utility;

import java.io.Serializable;
import java.time.LocalDateTime;

import org.apache.commons.lang.StringUtils;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

public class UserIdGenerator implements IdentifierGenerator {
	
	private static int counter = 101;
	
	@Override
	public Serializable generate(SharedSessionContractImplementor session, Object object) {
		int id = counter++;
		var now = LocalDateTime.now();
		return "U" + id + StringUtils.leftPad(String.valueOf(now.getSecond()*now.getHour()), 4, '9');
	}

}
