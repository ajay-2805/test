package com.infosys.ekart.account.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.ekart.account.dto.AccountDto;
import com.infosys.ekart.account.dto.LoginDto;
import com.infosys.ekart.account.dto.UpdateAccountDto;
import com.infosys.ekart.account.exception.EKartException;
import com.infosys.ekart.account.service.EKartAccountService;

@RestController
@RequestMapping("/account")
@Validated
@CrossOrigin
public class EKartAccountController {

	@Autowired
	private EKartAccountService service;

	@PostMapping
	public ResponseEntity<String> createAccount(@Valid @RequestBody AccountDto accountDto) throws EKartException {
		return ResponseEntity.ok(service.createAccount(accountDto));
	}

	@PutMapping("/{userId}")
	public ResponseEntity<String> updateAccount(@NotBlank @PathVariable String userId,
			@RequestBody UpdateAccountDto updateAccountDto) throws EKartException {
		service.updateAccount(userId, updateAccountDto);
		return ResponseEntity.ok("Account updated successfully.");
	}

	@PostMapping("/login")
	public ResponseEntity<AccountDto> loginUser(@Valid @RequestBody LoginDto loginDto) throws EKartException {
		return ResponseEntity.ok(service.login(loginDto));
	}

	@GetMapping("/{accountType}")
	public ResponseEntity<List<AccountDto>> getAccountsByAccountType(@NotBlank @PathVariable String accountType) {		
		return ResponseEntity.ok(service.getAccountsByAccountType(accountType));
	}

}
