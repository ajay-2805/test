package com.infosys.ekart.account.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.infosys.ekart.account.dto.AccountDto;
import com.infosys.ekart.account.dto.LoginDto;
import com.infosys.ekart.account.dto.UpdateAccountDto;
import com.infosys.ekart.account.entity.Account;
import com.infosys.ekart.account.exception.EKartException;
import com.infosys.ekart.account.exception.ExceptionConstants;
import com.infosys.ekart.account.repository.EKartAccountRepository;

@Service
public class EKartAccountServiceImpl implements EKartAccountService {

	@Autowired
	private EKartAccountRepository repo;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public String createAccount(AccountDto accountDto) throws EKartException {
		if (repo.findByEmailId(accountDto.getEmailId()).isPresent()) {
			throw new EKartException(ExceptionConstants.EMAIL_IN_USE);
		}
		return repo.saveAndFlush(convertDtoToEntity(accountDto)).getUserId();
	}

	@Override
	public void updateAccount(String userId, UpdateAccountDto updateAccountDto) throws EKartException {
		if (StringUtils.isBlank(updateAccountDto.getName()) && StringUtils.isBlank(updateAccountDto.getPassword())) {
			throw new EKartException(ExceptionConstants.UPDATE_INVALID_INPUT);
		}

		Account account = repo.findById(userId)
				.orElseThrow(() -> new EKartException(ExceptionConstants.ACCOUNT_NOT_FOUND));

		if (StringUtils.isNotBlank(updateAccountDto.getName())) {
			account.setName(updateAccountDto.getName());
		}

		if (StringUtils.isNotBlank(updateAccountDto.getPassword())) {
			account.setPassword(passwordEncoder.encode(updateAccountDto.getPassword()));
		}

		repo.saveAndFlush(account);
	}

	@Override
	public AccountDto login(LoginDto loginDto) throws EKartException {
		Optional<Account> account = repo.findByUserIdAndAccountType(loginDto.getUserId(), loginDto.getAccountType());
		if (account.isPresent() && passwordEncoder.matches(loginDto.getPassword(), account.get().getPassword())) {
			return this.convertEntityToDto(account.get());
		}
		throw new EKartException(ExceptionConstants.INVALID_CREDENTIALS);
	}

	@Override
	public List<AccountDto> getAccountsByAccountType(String accountType) {
		return repo.findByAccountType(accountType).stream().map(this::convertEntityToDto).collect(Collectors.toList());
	}

	private Account convertDtoToEntity(AccountDto accountDto) {
		Account account = new Account();
		account.setAccountType(accountDto.getAccountType());
		account.setEmailId(accountDto.getEmailId());
		account.setName(accountDto.getName());
		account.setPassword(passwordEncoder.encode(accountDto.getPassword()));
		return account;
	}

	private AccountDto convertEntityToDto(Account account) {
		AccountDto accountDto = new AccountDto();
		accountDto.setAccountType(account.getAccountType());
		accountDto.setEmailId(account.getEmailId());
		accountDto.setName(account.getName());
		accountDto.setUserId(account.getUserId());
		return accountDto;
	}

}
