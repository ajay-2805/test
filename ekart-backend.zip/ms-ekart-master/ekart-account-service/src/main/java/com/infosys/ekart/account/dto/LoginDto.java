package com.infosys.ekart.account.dto;

import javax.validation.constraints.NotBlank;

public class LoginDto {

	@NotBlank
	private String userId;

	@NotBlank
	private String password;
	
	@NotBlank
	private String accountType;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String id) {
		this.userId = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	
}
