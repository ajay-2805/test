package com.infosys.ekart.account.service;

import java.util.List;

import com.infosys.ekart.account.dto.AccountDto;
import com.infosys.ekart.account.dto.LoginDto;
import com.infosys.ekart.account.dto.UpdateAccountDto;
import com.infosys.ekart.account.exception.EKartException;

public interface EKartAccountService {

	public String createAccount(AccountDto accountDto) throws EKartException;
	
	public void updateAccount(String userId, UpdateAccountDto updateAccountDto) throws EKartException;
	
	public AccountDto login(LoginDto loginDto) throws EKartException;

	public List<AccountDto> getAccountsByAccountType(String accountType);
	
}
