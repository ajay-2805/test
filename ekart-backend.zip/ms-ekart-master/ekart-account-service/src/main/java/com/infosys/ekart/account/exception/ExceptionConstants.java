package com.infosys.ekart.account.exception;

public enum ExceptionConstants {
	
	SERVER_ERROR("server.error"),
	ACCOUNT_NOT_FOUND("account.not.found"),
	UPDATE_INVALID_INPUT("update.invalid.input"),
	EMAIL_IN_USE("email.in.use"),
	INVALID_CREDENTIALS("invalid.credentials");
	
	private final String type;
	
	private ExceptionConstants(String type) {
		this.type = type;
	}
	
	@Override
	public String toString() {
		return this.type;
	}
}
