package com.infosys.ekart.account.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.ekart.account.entity.Account;

public interface EKartAccountRepository extends JpaRepository<Account, String> {

	Optional<Account> findByEmailId(String emailId);

	Optional<Account> findByUserIdAndAccountType(String userId, String accountType);

	List<Account> findByAccountType(String accountType);

}
