insert into account (user_id, account_type, email_id, name, password) 
values ('U1111111', 'buyer', 'iamabuyer@glook.com', 'Saina Nehwal', 
'$2a$10$kQni5b1WLV9WYen.pPRz8u3HRC4wTmSd5x.qWi4XS3KzvI2KuP5Ca'); --Racq12@1

insert into account (user_id, account_type, email_id, name, password) 
values ('U9999999', 'seller', 'iamaseller@glook.com', 'Barack Obama', 
'$2a$10$DQ1GsP4MM.MeY0QN0LiS1.WSqe2P9parSjniDyhY1yuKODZELOKKG'); --YesWeC@n9

insert into account (user_id, account_type, email_id, name, password) 
values ('U2222222', 'buyer', 'iambuyer2@glook.com', 'Sachin Tendulkar', 
'$2a$10$kcTEcVhhkUQ/zUZetlfwCuzbrwUULDbwB3SUp.bYEXZgyJDD4pX9C'); --Hun100@2

insert into account (user_id, account_type, email_id, name, password) 
values ('U8888888', 'seller', 'iamseller2@glook.com', 'Donald Trump', 
'$2a$10$/6f6C.0BVdRYeV6ia6/TOeDrQSLTY3nUgifKT7MqmpsA1PfSamOjO'); --Amegre@t8

insert into account (user_id, account_type, email_id, name, password) 
values ('Buyer1', 'buyer', 'buyer1@gmail.com', 'Buyer', 
'$2a$10$idEQZt/ViSh2uGb3JZYwWeiegO1pL.rZg2N1LcxF1bIUGUsThdMDS'); --Buyer@123

insert into account (user_id, account_type, email_id, name, password) 
values ('Seller1', 'seller', 'seller1@gmail.com', 'Seller', 
'$2a$10$cZrcy4btG7QCbl0R4WpIQOXwaJZ.uCXiwqzuJCNCMyq2lLQWjwavi'); --Seller@123
